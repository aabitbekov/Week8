package java.Type;

public enum Types {
        ServletFilter,
        AnotherFilter
}
