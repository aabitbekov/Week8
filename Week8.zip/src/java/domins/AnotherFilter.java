package java.domins;

import java.interfaces.Filter;

public class AnotherFilter implements Filter {
    @Override
    public void Filtred() {
        System.out.println("This is another filter!");
    }
}
