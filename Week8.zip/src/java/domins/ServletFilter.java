package java.domins;

import java.interfaces.Filter;

public class ServletFilter implements Filter {
    @Override
    public void Filtred() {
        System.out.println("This is SERVLET FILTER!");
    }
}
