package java.interfaces;

public interface Filter {
    void Filtred();
}
